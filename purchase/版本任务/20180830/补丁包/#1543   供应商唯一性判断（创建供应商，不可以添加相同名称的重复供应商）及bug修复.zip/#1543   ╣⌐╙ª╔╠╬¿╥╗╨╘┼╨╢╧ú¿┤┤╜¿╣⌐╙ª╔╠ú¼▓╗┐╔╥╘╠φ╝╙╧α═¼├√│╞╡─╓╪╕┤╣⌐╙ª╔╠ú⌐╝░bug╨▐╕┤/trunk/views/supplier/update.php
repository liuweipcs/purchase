<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\tabs\TabsX;
use kartik\file\FileInput;
use yii\helpers\Url;
use app\services\BaseServices;
use app\services\SupplierServices;
use kartik\select2\Select2;
use kartik\date\DatePicker;
use yii\web\JsExpression;
use app\models\SupplierPaymentAccount;
use app\config\Vhelper;
/* @var $this yii\web\View */
/* @var $model app\models\Supplier */
/* @var $form yii\widgets\ActiveForm */
$this->title = Yii::t('app', '更新供应商');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', '供应商列表'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>



<?php $form = ActiveForm::begin(["options" => ["enctype" => "multipart/form-data"]]); ?>
<h3 class="fa-hourglass-3">基本信息</h3>
<div class="row">

    <input type="hidden" name="Supplier[is_push_to_k3cloud]" value="0">

    <div class="col-md-2"><?= $form->field($model, 'supplier_name')->textInput(['maxlength' => true,'placeholder'=>'易佰网络']) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'supplier_level')->dropDownList(SupplierServices::getSupplierLevel(), ['prompt' => '请选择供应商等级']) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'supplier_type')->dropDownList(SupplierServices::getSupplierType(), ['prompt' => '请选择供应商类型']) ?></div>
    <div class="col-md-2"> <label>首次合作时间</label>
        <?=
        DatePicker::widget([
            'name' => 'Supplier[first_cooperation_time]',
            'options' => ['placeholder' => ''],
            'value' => !empty($model->first_cooperation_time)?date('Y-m-d',strtotime($model->first_cooperation_time)):date('Y-m-d',time()),
            'pluginOptions' => [
                'autoclose' => true,
                'format' => 'yyyy-mm-dd',
                'todayHighlight' => true
            ]
        ])
        ?></div>
    <div class="col-md-2"><?= $form->field($model, 'store_link')->textInput(['maxlength' => true,'placeholder'=>'']) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'province')->dropDownList(BaseServices::getCityList(1),[
            'prompt'=>'--请选择省--',
            'required'=>true,
            'onchange'=>'
            $(".form-group.field-member-area").hide();
            $.post("'.yii::$app->urlManager->createUrl('supplier/sites').'?typeid=1&pid="+$(this).val(),function(data){
                $("select#supplier-city").html(data);
                $("select#supplier-area").html("<option>--请选择区--</option>");
            });',
        ]) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'city')->dropDownList(BaseServices::getCityList($model->province),
            [
                'prompt'=>'--请选择市--',
                'required'=>true,
                'onchange'=>'
            $(".form-group.field-member-area").show();
            $.post("'.yii::$app->urlManager->createUrl('supplier/sites').'?typeid=2&pid="+$(this).val(),function(data){
                $("select#supplier-area").html(data);
            });',
            ]) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'area')->dropDownList(BaseServices::getCityList($model->city),['prompt'=>'--请选择区--','required'=>true
        ]) ?></div>
    <div class="col-md-2"><?= $form->field($model, 'supplier_address')->textarea(['maxlength' => true])->label('详细地址') ?></div>
    <div class="col-md-2"><?= $form->field($model, 'invoice')->dropDownList([1=>'否',2=>'增值税发票',3=>'普票'],['prompt'=>'--是否开票--',]) ?></div>
    <div class="col-md-4"><?= $form->field($model, 'business_scope')->textarea(['maxlength' => true]) ?></div>



    <div class="col-md-3">
        <p style="color: red;">必填项，如果没有，用手机号码代替</p>
        <?= $form->field($model, 'credit_code')->textInput(['maxlength' => true, 'placeholder' => '']); ?>
    </div>


</div>
<?php
//支付方式

$pay='
    <table class="table table-hover ">
    <tr>
   <td>'.$form->field($model, "supplier_settlement")->dropDownList(SupplierServices::getSettlementMethod(), ["prompt" => "请选择结算方式",'required'=>true]).'</td>
    <td>'. $form->field($model, "payment_method")->dropDownList(SupplierServices::getDefaultPaymentMethod(), ["prompt" => "请选择支付方式",'required'=>true]).'</td>
    </tr>
</table>';

if($model->pay) {
    $pay .='<div class="col-md-2">'.Html::button('添加帐号', ['class' => 'btn btn-success add_user']).'</div>';
    $pay .= "<table class='table table-hover'>
	
                    <thead>
      
	                    <th>编号</th>
                        <th>支付平台</th>
                        <th>主行</th>                   
                       <th>支行</th>
                       <th colspan='2'style='text-align: center'>支行所在区域</th>
                        <td>账户类型	</td>
                        <th>开户名</th>
                        <th>账号</th>
                        <th>到账通知手机号</th>
                        <th>证件号</th>
                        <th>操作</th>
	
                    </thead>";
	$pay .= "<tbody class='pay'>";
    foreach ($model->pay as $k => $v) {
                  $pay .=  "<tr class='pay_list'>";
        $pay .='<td>'.$form->field($v, "pay_id[]")->input('text',['value'=>$v->pay_id,'readonly'=>true,'class'=>'form-control pay_id'])->label(false).'</td>';
        $pay .= '<td>'.$form->field($v, "payment_platform[]")->dropDownList(SupplierServices::getPaymentPlatform(),['class'=>'pay_info form-control','value'=>$v->payment_platform,'prompt'=>'请选择','required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        '</td>';
        $pay .= '<td>'.$form->field($v, "payment_platform_bank[]")->dropDownList(\app\models\UfxFuiou::getMasterBankInfo(),['class'=>'pay_info form-control','prompt'=>'请选择','value'=>!empty($v->payment_platform_bank)?$v->payment_platform_bank:'','required'=>in_array($model->payment_method,[3,5])?true:false])->label(false);
        $pay .= '<td>'.$form->field($v, "payment_platform_branch[]")->textInput(['class'=>'pay_info form-control','value'=> $v->payment_platform_branch,'placeholder'=>'请录入支行名称','required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .= '<td>'.$form->field($v, "prov_code[]")->dropDownList(\app\models\UfxFuiou::getProvInfo(),['class' => 'form-control pay_info prov','value'=> $v->prov_code,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .= '<td>'.$form->field($v, "city_code[]")->dropDownList(\app\models\UfxFuiou::getCityInfo(),['class' => 'form-control  pay_info city','value'=> $v->city_code,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .=  '<td>'.$form->field($v, "account_type[]")->dropDownList(['1'=>'对公','2'=>'对私'],['class' => 'form-control pay_info','value'=>$v->account_type,'prompt'=>'请选择','required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .='<td>'.$form->field($v, "account_name[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>"",'value'=>$v->account_name,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .='<td>'.$form->field($v, "account[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>"",'value'=>$v->account,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .= '<td>'.$form->field($v, "phone_number[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>"手机号",'value'=>$v->phone_number,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .= '<td>'.$form->field($v, "id_number[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>"证件号",'value'=>$v->id_number,'required'=>in_array($model->payment_method,[3,5])?true:false])->label(false).'</td>';
        $pay .= '<td>'.Html::button('删除', ['class' => 'btn btn-danger form-control']).'</td>';
        $pay.='</tr>';
    }

    $pay .= '   </tbody>
    </table>';
 }else {
    $payModel = new SupplierPaymentAccount();
    $pay='
    <table class="table table-hover ">
    <tr>
   <td>'.$form->field($model, "supplier_settlement")->dropDownList(SupplierServices::getSettlementMethod(), ["prompt" => "请选择结算方式"]).'</td>
    <td>'. $form->field($model, "payment_method")->dropDownList(SupplierServices::getDefaultPaymentMethod(), ["prompt" => "请选择支付方式"]).'</td>
 </tr>
</table>
    <table class="table table-hover ">
    
      <div class="col-md-2">'.Html::button('添加帐号', ['class' => 'btn btn-success add_user']).'</div>
        <thead>
        <tr>
            <th>支付平台</th>
            <th>主行</th>
            <th>支行</th>
            <th colspan="2" style="text-align: center">支行所在区域</th>
            <th>账户类型</th>
            <th>开户名</th>
            <th>账号</th>
            <th>到账通知手机号</th>
            <th>证件号</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody class="pay">
        <tr class="pay_list ">
            <td>'.$form->field($payModel, "payment_platform[]")->dropDownList(SupplierServices::getPaymentPlatform(),['class' => 'form-control payment_platform pay_info check_pay','prompt'=>'请选择'])->label(false).'</td><td>'.
        $form->field($payModel, "payment_platform_bank[]")->dropDownList(\app\models\UfxFuiou::getMasterBankInfo(),['class' => 'form-control pay_info pay_bank check_pay','prompt'=>'请选择'])->label(false).'</td><td>'

        .$form->field($payModel, "payment_platform_branch[]")->textInput(['class' => 'form-control pay_info','placeholder'=>'请录入支行名称'])->label(false).'</td>
             <td>'.$form->field($payModel, "prov_code[]")->dropDownList(\app\models\UfxFuiou::getProvInfo(),['class' => 'form-control prov pay_info','prompt'=>'请选择省'])->label(false).'</td>
             <td>'.$form->field($payModel, "city_code[]")->dropDownList([],['class' => 'form-control city pay_info','prompt'=>'请选择市'])->label(false).'</td>
             <td>'.$form->field($payModel, "account_type[]")->dropDownList(['1'=>'对公','2'=>'对私'],['class' => 'form-control account_type pay_info','prompt'=>'请选择'])->label(false).'</td>
            <td>'.$form->field($payModel, "account_name[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>""])->label(false).'</td>
            <td>'.$form->field($payModel, "account[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>""])->label(false).'</td>
            <td>'.$form->field($payModel, "phone_number[]")->textInput(['class'=>'pay_info form-control',"maxlength" => true,"placeholder"=>"手机号码"])->label(false).'</td>
            <td>'.$form->field($payModel, "id_number[]")->textInput(['class'=>'pay_info form-control','title'=>'对私账户为收款人身份证号,对公账户为收款公司组织机构代码',"maxlength" => true,"placeholder"=>"对私账户为收款人身份证号,对公账户为收款公司组织机构代码"])->label(false).'</td>
              <td>'.Html::button('删除', ['class' => 'btn btn-danger form-control']).'</td>


        </tbody>

    </table>
    ';
}
$supplier_buyer = \app\models\SupplierBuyer::find()->andFilterWhere(['supplier_code'=>$model->supplier_code,'status'=>1])->select('type,buyer')->indexBy('type')->asArray()->all();
$inbuyer = isset($supplier_buyer[1])&&!empty($supplier_buyer[1]) ? 'checked="checked"' : '';
$inbuyername = isset($supplier_buyer[1])&&!empty($supplier_buyer[1]) ? $supplier_buyer[1]['buyer'] : '';
$hwcbuyer = isset($supplier_buyer[2])&&!empty($supplier_buyer[2]) ? 'checked="checked"' : '';
$hwcbuyername = isset($supplier_buyer[2])&&!empty($supplier_buyer[2]) ? $supplier_buyer[2]['buyer'] : '';
$FBAbuyer = isset($supplier_buyer[3])&&!empty($supplier_buyer[3]) ? 'checked="checked"' : '';
$FBAbuyername = isset($supplier_buyer[3])&&!empty($supplier_buyer[3]) ? $supplier_buyer[3]['buyer']: '';
$model_buyer = new \app\models\SupplierBuyer();
$inbuyerhtml = $view == 'update' ? $form->field($model_buyer, 'buyer[]')->widget(Select2::classname(), [
    'options' => ['placeholder' => '请输入采购员 ...','id'=>'IN','value'=>$inbuyername],
    'data' =>BaseServices::getEveryOne('','name'),
    'pluginOptions' => [
        'language' => [
            'errorLoading' => new JsExpression("function () { return 'Waiting...'; }"),],
    ],])->label('') :$inbuyername;
$hwcbuyerhtml =$view == 'update' ? $form->field($model_buyer, 'buyer[]')->widget(Select2::classname(), [
    'options' => ['placeholder' => '请输入采购员 ...','id'=>'HWC','value'=>$hwcbuyername,'disabled'=>$view=='update'?false:true],
    'data' =>BaseServices::getEveryOne('','name'),
    'pluginOptions' => [
        'language' => [
            'errorLoading' => new JsExpression("function () { return 'Waiting...'; }"),],
    ],])->label('') :$hwcbuyername;
$FBAbuyerhtml = $view == 'update' ? $form->field($model_buyer, 'buyer[]')->widget(Select2::classname(), [
    'options' => ['placeholder' => '请输入采购员 ...','id'=>'FBA','value'=>$FBAbuyername,'disabled'=>$view=='update'?false:true],
    'data' =>BaseServices::getEveryOne('','name'),
    'pluginOptions' => [
        'language' => [
            'errorLoading' => new JsExpression("function () { return 'Waiting...'; }"),],
    ],])->label('') : $FBAbuyername;
$buyer='
    <table class="table table-hover ">
        <thead>
        <tr>
           <th></th>
            <th>部门</th>
            <th>采购员</th>
        </tr>
        </thead>
        <tbody class="buyer">
            <tr class="buyer_list ">
                <td><input type="checkbox" name="SupplierBuyer[type][]" value=1 '.$inbuyer.'></td>
                <td>国内仓</td>
                <td>'.$inbuyerhtml.'
                </td>
            </tr>
            <tr class="buyer_list ">
                <td><input type="checkbox" name="SupplierBuyer[type][]" value=2 '.$hwcbuyer.'></td>
                <td>海外仓</td>
                <td>'.$hwcbuyerhtml.'
                </td>
            </tr>
            <tr class="buyer_list ">
                <td><input type="checkbox"  class="FBABuyer" name="SupplierBuyer[type][]" value=3 '.$FBAbuyer.'></td>
                <td>FBA</td>
                <td>'.$FBAbuyerhtml.'
                </td>
            </tr>
        </tbody>
    </table>';
$modelline = new  \app\models\SupplierProductLine();
$addline = $view =='update' ? Html::button('添加产品线', ['class' => 'btn btn-success add_line']):'';
if(empty($model->line)){
$line='
    <table class="table table-hover ">
    <div class="col-md-2">'.$addline.'</div>
        <thead>
        <tr>
           <th>一级产品线</th>
            <th>二级产品线</th>
            <th>三级产品线</th>
        </tr>
        </thead>
        <tbody class="line">
        <tr class="line_list ">
                    <td>'.$form->field($modelline, "first_product_line[]")->dropDownList(BaseServices::getProductLine(),['class' => 'form-control ','prompt'=>'选择一级产品线','disabled'=>$view=='update'?false:true,
        'onclick'=>'
                        $.post("'.yii::$app->urlManager->createUrl('supplier/line').'?pid="+$(this).val(),function(data){
                            $(".second").html(data);
                            $(".second").trigger("click");
                        });',
    ])->label('').'</td>
                    <td>'.$form->field($modelline, "second_product_line[]")->dropDownList(BaseServices::getProductLineList($modelline->first_product_line),['class' => 'form-control second ','prompt'=>'选择二级产品线','disabled'=>$view=='update'?false:true,
        'onclick'=>'
                        $.post("'.yii::$app->urlManager->createUrl('supplier/line').'?pid="+$(this).val(),function(data){
                            $(".third").html(data);
                        });',])->label('').'</td>
                    <td>'.$form->field($modelline, "third_product_line[]")->dropDownList(BaseServices::getProductLineList($modelline->second_product_line),['class' => 'form-control third','prompt'=>'选择三级产品线','disabled'=>$view=='update'?false:true])->label('').'</td>
                    <td>'.Html::button('删除', ['class' => 'btn btn-danger form-control','style'=>'margin-top:20px;']).'</td>
        </tbody>

    </table>';
}else{
    $line='
    <table class="table table-hover ">
    <div class="col-md-2">'.$addline.'</div>
        <thead>
        <tr>
           <th>一级产品线</th>
            <th>二级产品线</th>
            <th>三级产品线</th>
        </tr>
        </thead>
        <tbody class="line">';
    foreach($model->line as $linevalue){
        $line.='<tr class="line_list ">
                    <td>'.$form->field($linevalue, "first_product_line[]")->dropDownList(BaseServices::getProductLine(),['class' => 'form-control ','value'=>$linevalue->first_product_line,'disabled'=>$view=='update'?false:true,
                        'onclick'=>'
                        var second = $(this).closest("tr").find(".second");
                        $.post("'.yii::$app->urlManager->createUrl('supplier/line').'?pid="+$(this).val(),function(data){
                            second.html(data);
                            second.trigger("click");
                        });',
        ])->label('').'</td>
                    <td>'.$form->field($linevalue, "second_product_line[]")->dropDownList(BaseServices::getProductLineList($linevalue->first_product_line),['class' => 'form-control second ','value'=>$linevalue->second_product_line,'disabled'=>$view=='update'?false:true,
                        'onclick'=>'
                        var third = $(this).closest("tr").find(".third");
                        $.post("'.yii::$app->urlManager->createUrl('supplier/line').'?pid="+$(this).val(),function(data){
                            third.html(data);
                        });',])->label('').'</td>
                    <td>'.$form->field($linevalue, "third_product_line[]")->dropDownList(BaseServices::getProductLineList($linevalue->second_product_line),['class' => 'form-control third','value'=>$linevalue->third_product_line,'disabled'=>$view=='update'?false:true])->label('').'</td>
                    <td>'.Html::button('删除', ['class' => 'btn btn-danger form-control','style'=>'margin-top:20px;']).'</td></tr>';
    }
    $line.='</tbody></table>';
}
//结束
//联系我们
$contact="
    <table class='table table-hover'>

        <thead>
        <tr>

            <th>联系人</th>
            <th>法人代表</th>
            <th>联系电话</th>
            <th>中文联系地址</th>
            <th>QQ</th>
            <th>微信</th>
            <th>邮箱</th>
            <th>旺旺</th>
        </tr>
        </thead>";
$contact.="<tbody class='contact' >";
if($model->contact)
{
    foreach ($model->contact as $k => $v)
    {

        $contact.= "<tr class='contact_list' >";
        $contact.= '<td > '.$form->field($model, "contact_person")->textInput(['class' => 'form-control ','placeholder'=>'联系人','value'=>!empty($v->contact_person)?$v->contact_person:'','name'=>"SupplierContactInformation[$k][contact_person]"])->label('').' </td >';
        
        $contact.= '<td > '.$form->field($model, "corporate")->textInput(['class' => 'form-control ','placeholder'=>'法人代表','value'=>!empty($v->corporate)?$v->corporate:'','name'=>"SupplierContactInformation[$k][corporate]"])->label('').' </td >';

        $contact.= '<td > '.$form->field($model, "contact_number")->textInput(['class' => 'form-control ','max'=>"20",'placeholder'=>'联系电话','value'=>!empty($v->contact_number)?$v->contact_number:'','name'=>"SupplierContactInformation[$k][contact_number]"])->label('').' </td >';
        $contact.='<td > '.$form->field($model, "chinese_contact_address")->textInput(['class' => 'form-control ','placeholder'=>'中文联系地址','value'=>!empty($v->chinese_contact_address)?$v->chinese_contact_address:'','name'=>"SupplierContactInformation[$k][chinese_contact_address]"])->label('').' </td >';
        $contact.='<td > '.$form->field($model, "qq")->textInput(['class' => 'form-control ','placeholder'=>'QQ','max'=>"20",'value'=>!empty($v->qq)?$v->qq:'','name'=>"SupplierContactInformation[$k][qq]"])->label('').' </td >';
        $contact.='<td > '.$form->field($model, "micro_letter")->textInput(['class' => 'form-control ','placeholder'=>'微信','max'=>"20",'value'=>!empty($v->micro_letter)?$v->micro_letter:'','name'=>"SupplierContactInformation[$k][micro_letter]"])->label('').' </td >';
        
        $contact.='<td > '.$form->field($model, "email")->input('email', ['class' => 'form-control ','placeholder'=>'邮箱','max'=>"20",'value'=>!empty($v->email)?$v->email:'','name'=>"SupplierContactInformation[$k][email]"])->label('').' </td >';
        
        $contact.='<td > '.$form->field($model, "want_want")->textInput(['class' => 'form-control ','placeholder'=>'旺旺','max'=>"20",'value'=>!empty($v->want_want)?$v->want_want:'','name'=>"SupplierContactInformation[$k][want_want]"])->label('').' </td >';
        $contact .= '</tr>';
    }
}else{
    $contact.= "<tr class='contact_list' >";
    $contact.= '<td > '.$form->field($model, "contact_person[]")->textInput(['class' => 'form-control ','placeholder'=>'联系人','value'=>!empty($model->contact_person)?$model->contact_person:'','name'=>"SupplierContactInformation[contact_person][]"])->label('').' </td >';
    
    $contact.= '<td > '.$form->field($model, "corporate[]")->textInput(['class' => 'form-control ','placeholder'=>'法人代表','value'=>!empty($model->corporate)?$model->corporate:'','name'=>"SupplierContactInformation[corporate][]"])->label('').' </td >';

    $contact.= '<td > '.$form->field($model, "contact_number[]")->textInput(['class' => 'form-control ','max'=>"20",'placeholder'=>'联系电话','value'=>!empty($model->contact_number)?$model->contact_number:'','name'=>"SupplierContactInformation[contact_number][]"])->label('').' </td >';
    $contact.='<td > '.$form->field($model, "chinese_contact_address[]")->textInput(['class' => 'form-control ','placeholder'=>'中文联系地址','value'=>!empty($model->chinese_contact_address)?$model->chinese_contact_address:'','name'=>"SupplierContactInformation[chinese_contact_address][]"])->label('').' </td >';
    $contact.='<td > '.$form->field($model, "qq[]")->textInput(['class' => 'form-control ','placeholder'=>'QQ','max'=>"20",'value'=>!empty($model->qq)?$model->qq:'','name'=>"SupplierContactInformation[qq][]"])->label('').' </td >';
    $contact.='<td > '.$form->field($model, "micro_letter[]")->textInput(['class' => 'form-control ','placeholder'=>'微信','max'=>"20",'value'=>!empty($model->micro_letter)?$model->micro_letter:'','name'=>"SupplierContactInformation[micro_letter][]"])->label('').' </td >';
    
    $contact.='<td > '.$form->field($model, "email[]")->input('email', ['class' => 'form-control ','placeholder'=>'邮箱','max'=>"255",'value'=>!empty($model->email)?$model->email:'','name'=>"SupplierContactInformation[email][]"])->label('').' </td >';
    
    $contact.='<td > '.$form->field($model, "want_want[]")->textInput(['class' => 'form-control ','placeholder'=>'旺旺','max'=>"20",'value'=>!empty($model->want_want)?$model->want_want:'','name'=>"SupplierContactInformation[want_want][]"])->label('').' </td >';


    $contact .= '</tr>';
}
$contact.= '</tbody></table>';
//结束*/


$p1=\yii\helpers\ArrayHelper::toArray($model->img,[
    'app\models\SupplierImages' => [
        'image_url'
    ]
]);
$p1=\yii\helpers\ArrayHelper::getColumn($p1,'image_url');

$images_url = $p1 ? Html::a('下载附属文件',['download','filename'=>$p1]):'';
$images_url .= $form->field($model, 'image_url')->widget(FileInput::classname(), ['options' => ['multiple' => true,'name'=>'SupplierImages[image_url]'],
            'pluginOptions' => [
                // 需要预览的文件格式
                'previewFileType' => 'image',
                // 预览的文件
                'initialPreview' =>$p1,
                // 需要展示的图片设置，比如图片的宽度等
                'initialPreviewConfig' =>$p2,
                // 是否展示预览图
                'initialPreviewAsData' => true,
                'allowedFileExtensions' => ['jpg', 'gif', 'png','pdf','xls','xlsx','csv','doc'],
                // 异步上传的接口地址设置
                'uploadUrl' => Url::toRoute(['/supplier/async-image']),
                'uploadAsync' => true,
                // 最少上传的文件个数限制
                'minFileCount' => 1,
                // 最多上传的文件个数限制
                'maxFileCount' => 10,
                'maxFileSize' => 2000,//限制图片最大200kB
                // 是否显示移除按钮，指input上面的移除按钮，非具体图片上的移除按钮
                'showRemove' => true,
                // 是否显示上传按钮，指input上面的上传按钮，非具体图片上的上传按钮
                'showUpload' => false,
                //是否显示[选择]按钮,指input上面的[选择]按钮,非具体图片上的上传按钮
                'showBrowse' => true,
                // 展示图片区域是否可点击选择多文件
                'browseOnZoneClick' => true,
                // 如果要设置具体图片上的移除、上传和展示按钮，需要设置该选项
                'fileActionSettings' => [
                    // 设置具体图片的查看属性为false,默认为true
                    'showZoom' => false,
                    // 设置具体图片的上传属性为true,默认为true
                    'showUpload' => true,
                    // 设置具体图片的移除属性为true,默认为true
                    'showRemove' => true,
                ],
            ],
            // 一些事件行为
            'pluginEvents' => [
                // 上传成功后的回调方法，需要的可查看data后再做具体操作，一般不需要设置
                'fileuploaded' => 'function(event, data, previewId, index) {
                        $(event.currentTarget.closest("form")).append(data.response.imgfile);
                    }',
            ],

        ])->label('附属图片(只能在此基础上追加图片,你并不能删除以前图片,图片上传时,会把当前附图隐藏)');


?>

<?php

$items = [
    [
        'label'=>'<i class="glyphicon glyphicon-contact"></i> 联系方式',
        'content'=>$contact,
        'active'=>$view =='update'?false:true

    ],

    [
        'label'=>'<i class="glyphicon glyphicon-equalizer"></i> 产品线',
        'content'=> $line,

    ],
    [
        'label'=>'<i class="glyphicon glyphicon-buyer"></i> 采购员(部门必选)',
        'content'=> $buyer,

    ],
    [
        'label'=>'<i class="glyphicon glyphicon-yen"></i> 支付方式',
        'content'=> $pay,

    ],

    [
        'label'=>'<i class="glyphicon glyphicon-book"></i> 合同注意事项',
        'content'=>$form->field($model,'contract_notice')->textarea(['col'=>10,'rows'=>5]),

    ],
    [
        'label'=>'<i class="glyphicon glyphicon-book"></i> 附属文件',
        // 'content'=>$form->field($model,'file')->fileInput(),
    ],
    [
        'label'=>'<i class="glyphicon glyphicon-picture"></i> 附属图片',
        'content'=>$images_url,

    ],

];

echo TabsX::widget([
    'items'=>$items,
    'position'=>TabsX::POS_ABOVE,
    'encodeLabels'=>false,
]);?>
<?php if($view=='update'){ ?>
<div class="form-group">
    <?= Html::submitButton($model->isNewRecord ? Yii::t('app', '创建') : Yii::t('app', '更新'), ['class' => $model->isNewRecord ? 'btn btn-success update' : 'btn btn-primary update']) ?>
</div>
<?php } ?>

<?php ActiveForm::end(); ?>


<?php
$payUrl = Url::toRoute('pay-method');
$cityUrl = Url::toRoute('ufx-fuiou/get-city');
$buyerUrl = Url::toRoute('buyer');
$js = <<<JS
        var spotMax = 2;
        //支付方式
        if($(".pay_list").size() >= 4) {
          $("button.add_user").hide();
        }
        $("button.add_user").click(function(){

         addSpot(this, 4,'pay','pay_list');
        });
        $("button.add_line").click(function(){

         addSpot(this, spotMax,'line','line_list');
        });
        //联系我们
        if($(".contact_list").size() >= spotMax) {
          $('button.add_contact').hide();
        }
        if($(".contact_list").size() >= spotMax) {
          $("button.add_line").hide();
        }
        $("button.add_contact").click(function(){

         addSpot(this, spotMax,'contact','contact_list');
        });
        $("button.btn-danger").click(function(){
            //保留最后一个不让删除
            if($(".pay_list").size() > 1)
            {
                $(this).parent().parent().remove();
            }
            if($(".pay_list").size() < spotMax)
            {
                $("button.add_user").show();
            }
            if($(".line_list").size() < spotMax)
            {
                $("button.add_line").show();
            }
            //保留最后一个不让删除

            if($(".contact_list").size() > 1)
            {
                $(this).parent().parent().remove();
            }
            if($(".line_list").size() > 1)
            {
                console.log($(".line_list").size());
                $(this).parent().parent().remove();
            }
        });

        /*公用复制*/
        function addSpot(obj, sm, father_class,child_class) {
            if($("."+child_class).size() <= 0)
            {

                alert('没有一行数据可进行复制');
            }
            var clone  = $("."+child_class).first().clone();
            clone.find('input').val('');
            clone.find('input').prop('readonly',false);
            clone.find('input.pay_id').prop('readonly',true);
            clone.find('select').val('');
          $("."+father_class).append(clone)
          .find("button.btn-danger").click(function(){
            //保留最后一个不让删除

            if($("."+ child_class).size() > 1){
                $(this).parent().parent().remove();
            }

            $('button.btn-success').show();
            });

            if($("."+ child_class).size() >= sm) {
                $('button.btn-success').hide();
            }
        };

        $('button.update').click(function(){
            var payplatcount=0;
            $("[name='SupplierPaymentAccount[payment_platform][]']").each(function() {
              console.log($(this).val());
              if($(this).val()==6){
                  payplatcount++;
              }
            });
            if(payplatcount>1){
                layer.msg('富友平台银行只能维护一张');
                return false;
            }
            var str = '';
            $('[name="SupplierBuyer[type][]"]').each(function(){
                if($(this).is(':checked')){
                    str+=$(this).val();
                }
            });
            if(str==''){
                layer.msg('必须选择一个部门');
                return false;
            }
        });
        $(document).on('change','#supplier-payment_method',function() {
            var paymethodArray = ['3','5'];
          if($.inArray($(this).val(),paymethodArray)!==-1){
              $('.pay_info').prop('required',true);
          }else{
              $('.pay_info').prop('required',false);
          }
        });
        $(document).on('change','.prov',function() {
        var prov = $(this).val();
        obj = $(this);
        $(this).closest('tr').find('.city').html('<option value="">请选择</option>');
        var loading = layer.load(6 , {shade : [0.5 , '#BFE0FA']});
        $.get("{$cityUrl}",{prov:prov},function(data){
            layer.close(loading);
            obj.closest('tr').find('.city').html(data);
        });
        });

        

JS;

$this->registerJs($js);
?>