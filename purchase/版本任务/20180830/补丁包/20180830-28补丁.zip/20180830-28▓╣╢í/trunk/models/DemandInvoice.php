<?php
namespace app\models;
use yii;
use yii\base\Model;

class DemandInvoice extends \yii\db\ActiveRecord
{
}