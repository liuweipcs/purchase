<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\config\Vhelper;
use kartik\select2\Select2;
use app\services\BaseServices;
use app\services\SupplierServices;
use app\models\ProductTaxRate;
use app\models\PurchaseOrderItems;
use app\services\PurchaseOrderServices;
use app\models\SupplierPaymentAccount;
$this->title = '海外仓采购合同-申请付款';
$this->params['breadcrumbs'][] = '海外仓';
$this->params['breadcrumbs'][] = '采购合同';
$this->params['breadcrumbs'][] = $this->title;
?>
<style type="text/css">
    .tt {
        width: 200px;
        text-align: center;
    }
    .cc {
        font-size: 16px;
        color: red;
    }
    .box-span span {
        display: inline-block;
        padding: 0px 15px;
        color: red;
        font-size: 15px;
    }
</style>
<?php $form = ActiveForm::begin(['id' => 'compact-payment']); ?>
<div id="div1">
    <?php if ($model->source == 1) : ?>
    <h4><?= $compact_number ?> 申请付款</h4>
    <a class="btn btn-info" href="/purchase-compact/print-compact?id=<?php echo $compact_model->id?>" target="_blank">查看采购订单合同</a>
    <?php else : ?>
    <h4><?= $model->pur_number ?> 申请付款</h4>
    <?php endif; ?>
    
    <div class="my-box">
        <table class="my-table">
            <tr>
                <th colspan="6">基本信息</th>
            </tr>
            <tr>
                <td><strong>供应商名称</strong></td>
                <td><?= $model->supplier_name ?></td>
                <td><strong>是否退税</strong></td>
                <td>
                    <?php if($model->is_drawback == 1): ?>
                        <span class="label label-info">不退税</span>
                    <?php elseif($model->is_drawback == 2): ?>
                        <span class="label label-success">退税</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td><strong>结算方式</strong></td>
                <td><?= !empty($model->account_type) ? SupplierServices::getSettlementMethod($model->account_type) : ''; ?></td>
                <td><strong>结算比例</strong></td>
                <td>
                <?php 
                    $settlement_ratio = $pay_model->settlement_ratio;
                    echo $settlement_ratio;
                    $settlement_ratio = explode('+', $settlement_ratio);
                ?>
                </td>
            </tr>
            <tr>
                <td><strong>支付方式</strong></td>
                <td><?= !empty($model->pay_type) ? SupplierServices::getDefaultPaymentMethod($model->pay_type) : ''; ?></td>
            	<td>运费支付</td>
            	<td><?php echo $pay_model->freight_payer == 1 ? '甲方支付' : '乙方支付';?></td>
            </tr>
        </table>
    </div>
    
    <div class="my-box">
        <table class="my-table">
            <tr>
            	<th>采购单号</th>
            	<th>商品信息</th>
            	<th>单价</th>
            	<th>数量</th>
            	<th>采购金额</th>
            	<th>已请金额</th>
            	<th>运费</th>
            	<th>优惠额</th>
            	<th>请款方式</th>
            	<th>结算比例</th>
            	<th>请款金额</th>
            </tr>
            <?php 
                $totalprice = 0; $sku_total = 0; foreach ($items as $item) : 
                $price = $item->price;
                $totalprice += $price*$item->purchase_quantity;
                $sku_total += $item->purchase_quantity;
            ?>
            <input type="hidden" name="id[]" value="<?php echo $item->demand_number;?>" />
            <input type="hidden" name="price[<?php echo $item->demand_number;?>]" value="<?php echo $price;?>" />
            <tr class="item" id="item-<?php echo $item->demand_number;?>"
            	data-demand-number="<?php echo $item->demand_number;?>" 
            	data-quantity="<?php echo $item->purchase_quantity?>"
            	data-item-totalprice="<?php echo $item->purchase_quantity*$price?>"
            	data-has-prce="<?php echo isset($has_amount[$item->demand_number]) ? $has_amount[$item->demand_number] : 0?>">
            	<td><?php echo $demand_maps[$item->demand_number];?></td>
            	<td>
            		SKU:<?php echo $item->sku?><br>
            		<?php echo $item->product_name?>
            	</td>
            	<td><?php echo $price; ?></td>
            	<td>
            	订单数量 : <?php echo $item->purchase_quantity?><br>
                            取消数量 : <?php echo $item->cancel_cty;?><br>
                            收货数量 : <?php echo $item->rqy?><br>
                            未到货数量 : <?php echo $item->purchase_quantity - $item->cty - $item->cancel_cty;?><br>
                            入库数量 : <?php echo $item->cty?>
            	</td>
            	<td><?php echo $price*$item->purchase_quantity;?></td>
            	<td>
            		<?php echo isset($has_amount[$item->demand_number]) ? $has_amount[$item->demand_number] : 0?>
            	</td>
            	<td>
            		<input id="freight-<?php echo $item->demand_number;?>" type="text" name="freight[<?php echo $item->demand_number;?>]" value="0" style="width:60px" readonly />
            	</td>
            	<td>
            		<input id="discount-<?php echo $item->demand_number;?>" type="text" name="discount[<?php echo $item->demand_number;?>]" value="0" style="width:60px" readonly />
            	</td>
            	<td>
            		<select class="price_type" id="price-type-<?php echo $item->demand_number;?>" data-demand-number="<?php echo $item->demand_number;?>" name="price_type[<?php echo $item->demand_number;?>]">
            			<option value="1">比例请款</option>
            			<option value="2">手动请款</option>
            		</select>
            	</td>
            	<td>
                	<select class="pay_ratio" id="pay-ratio-<?php echo $item->demand_number;?>" data-demand-number="<?php echo $item->demand_number;?>" name="pay_ratio[<?php echo $item->demand_number;?>]">
            		<option value="0">请选择</option>
            		<?php foreach ($settlement_ratio as $k=>$ratio) : 
            		  $ratio = intval($ratio);
            		?>
            		<option value="<?php echo $ratio;?>"><?php echo $ratio.'%/'.$item->purchase_quantity*$price*$ratio/100;?></option>
            		<?php endforeach; ?>
        			</select>
            	</td>
            	<td>
            		<input class="pay_amount" id="pay-amount-<?php echo $item->demand_number;?>" type="text" name="pay_amount[<?php echo $item->demand_number;?>]" value="0" style="width:60px" readonly />
            	</td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <div class="my-box">
    	<div class="col-md-1">
            <label>产品总额</label>
            <input type="text" class="form-control" value="<?php echo $totalprice;?>" readonly>
        </div>
        <div class="col-md-1">
            <label>已申请金额</label>
            <input type="text" class="form-control" value="<?php echo $pay_amount_total;?>" readonly>
        </div>
        <div class="col-md-1">
            <label>可申请金额</label>
            <input type="text" class="form-control" value="<?php echo $totalprice - $pay_amount_total;?>" readonly>
        </div>
        <div class="col-md-1">
            <label>总运费</label>
            <input type="number" id="freight" name="order_freight" class="form-control" value="0" <?php if ($pay_model->freight_payer == 2) {echo 'readonly';}?> >
        </div>
        <div class="col-md-1">
            <label>总优惠</label>
            <input type="number" id="discount" name="order_discount" class="form-control" value="0">
        </div>
        <div class="col-md-1">
            <label>请款总金额</label>
            <input type="number" id="pay_price" name="pay_price" class="form-control" value="0" readonly>
        </div>
        <div class="col-md-2">
            <label>账号</label>
            <?php echo Html::dropDownList("purchase_account", '', BaseServices::getAlibaba(), ['class'=>'form-control','prompt'=>'请选择']);?>
        </div>
        <div class="col-md-2">
            <label>拍单号</label>
            <input type="text" name="pai_number" class="form-control" value="">
        </div>
    </div>
    <div class="my-box" style="clear:both">
    	备注:<textarea name="create_notice" rows="3" class="form-control" style="width:600px"></textarea>
    </div>
    <div class="my-box" style="clear:both">
        <button class="btn btn-success" type="button" id="sub-btn"><?php echo $model->source == 1 ? '去填写付款申请书' : '提交审核';?></button>
    </div>
</div>
<?php if ($model->source == 1) : ?>
<?php 
$supplierAccount = SupplierPaymentAccount::find()->where(['supplier_code' => $model->supplier_code])->one();
$account = $account_name = $payment_platform_branch = '';
if($supplierAccount) {
    $account = $supplierAccount->account;
    $account_name = $supplierAccount->account_name;
    if (empty($supplierAccount->payment_platform_bank)) {
        $payment_platform_branch = '';
    } else {
        $payment_platform_branch = SupplierServices::getPayBank($supplierAccount->payment_platform_bank).' '.$supplierAccount->payment_platform_branch;
    }
}
?>
<div id="div2" style="display:none">
	<div style="width: 756px;background-color: #fff;">
        <table class="table table-bordered" style="margin-bottom: 0;">
            <tr>
                <th colspan="8" style="text-align: center;font-weight: bold;">付款申请书</th>
            </tr>
            <tr>
                <th colspan="2"><?= BaseServices::getBuyerCompany($model->is_drawback,'name'); ?></th>
                <th colspan="4"><?= date('Y年m月d日', time()) ?></th>
                <th colspan="2">合同号：<?= $compact_number ?></th>
            </tr>
            <tr>
                <td>收款单位</td>
                <td><?= $model->supplier_name ?></td>
                <td colspan="6">付款原因</td>
            </tr>
            <tr>
                <td>账号</td>
                <td><?= $account ?><input type="hidden" name="account" value="<?= $account ?>" /></td>
                <td rowspan="5" colspan="6" style="width: 50%;vertical-align: top;">
                <textarea name="payment_reason" class="form-control" rows="6"><?= implode(',',$pur_numbers) ?></textarea>
                </td>
            </tr>
            <tr>
                <td>开户行</td>
                <td><?= $payment_platform_branch ?><input type="hidden" name="payment_platform_branch" value="<?= $payment_platform_branch ?>" /></td>
            </tr>
            <tr>
                <td>金额</td>
                <td id="payment-amount2"></td>
            </tr>
            <tr>
                <td>附件</td>
                <td id="payment-amount"></td>
            </tr>
            <tr>
                <td>审批</td>
                <td>总经办</td>
            </tr>
        </table>
        <table class="table table-bordered">
            <tr>
                <td>财务总监</td>
                <td style="width: 113px;"></td>
                <td>记账</td>
                <td style="width: 113px;"></td>
                <td>采购经理</td>
                <td style="width: 113px;"></td>
                <td>制单</td>
                <td style="width: 113px;"></td>
            </tr>
        </table>
    </div>
    <div class="my-box">
        <button type="submit" class="btn btn-success">提交审核</button> &nbsp;
        <a href="javascript:;" onclick='javascript:$("#div1").show();$("#div2").hide();'>返回上一步</a>
    </div>
</div>
<?php endif; ?>
<?php ActiveForm::end(); ?>
<?php
$js = <<<JS
var sku_total = $sku_total;
var source = $model->source;
$(function(){
    $('.price_type').change(function() {
        var demand_number = $(this).attr("data-demand-number");
        if ($(this).val() == "1") {
            $("#pay-amount-"+demand_number).attr("readonly", true);
            $("#pay-ratio-"+demand_number).attr("disabled", false);
        } else {
            $("#pay-amount-"+demand_number).attr("readonly", false);
            $("#pay-ratio-"+demand_number).val(0);
            $("#pay-ratio-"+demand_number).attr("disabled", true);
            $("#pay-amount-"+demand_number).val(0);
            $("#pay-amount-"+demand_number).select();
        }
        totalprice();
    });

    $('.pay_ratio').change(function() {
        totalprice();
    });

    $("#freight").change(function(){
        var freight = parseFloat($(this).val());
        if (isNaN(freight) || freight < 0) {
            $(this).val(0);
            freight = 0;
        }
        freight = freight.toFixed(2);
        $(this).val(freight);
        $(".item").each(function(){
            var demand_number = $(this).attr("data-demand-number");
            var item_freight = (parseInt($(this).attr("data-quantity"))/sku_total)*freight;
            $("#freight-"+demand_number).val(item_freight.toFixed(2));
        })
        totalprice();
    })

    $("#discount").change(function(){
        var discount = parseFloat($(this).val());
        if (isNaN(discount) || discount < 0) {
            $(this).val(0);
            discount = 0;
        }
        discount = discount.toFixed(2);
        var pay_price = parseFloat($("#pay_price").val());
        $(this).val(discount);
        $(".item").each(function(){
            var demand_number = $(this).attr("data-demand-number");
            var item_discount = (parseInt($(this).attr("data-quantity"))/sku_total)*discount;
            $("#discount-"+demand_number).val(item_discount.toFixed(2));
        })
        totalprice();
    })
    
    $(".pay_amount").blur(function(){
        var value = parseFloat($(this).val());
        if (isNaN(discount) || discount < 0) {
            $(this).val(0);
            discount = 0;
        }
        $(this).val(value.toFixed(2));
        totalprice();
    })

    $('#sub-btn').click(function() {
        var pay_price = $("#pay_price").val();
        if(pay_price == 0) {
            layer.msg('请款金额不能为0');
            return false;
        }
        if (source == 1) {
            $("#payment-amount").html(pay_price);
            $.post('get-rmb', {price:pay_price}, function (data) {
                $("#payment-amount2").html(data);
            });
            $("#div1").hide();
            $("#div2").show();
        } else {
            $('#compact-payment').submit();
        }
    });

    totalprice();
});

function totalprice() {
    var pay_price = 0;
    $(".item").each(function(){
        var demand_number = $(this).attr("data-demand-number");
        if ($("#price-type-"+demand_number).val() == "1") {
            var pay_ratio = parseInt($("#pay-ratio-"+demand_number).val());
            var item_totalprice = parseFloat($("#item-"+demand_number).attr('data-item-totalprice'));
            var real_item_totalprice = item_totalprice*pay_ratio/100;
            $("#pay-amount-"+demand_number).val(real_item_totalprice);
        } else {
            var real_item_totalprice = parseFloat($("#pay-amount-"+demand_number).val());
            if (isNaN(real_item_totalprice)) {
                real_item_totalprice = 0;
                $("#pay-amount-"+demand_number).val(0.00);
            }
        }
        pay_price += real_item_totalprice;
    })
    pay_price += parseFloat($("#freight").val());
    pay_price -= parseFloat($("#discount").val());
    if (pay_price <= 0) {
        $("#discount").val(0);
        $("#discount").change();
        $("#discount").select();
        layer.msg("优惠金额不能超过总费用");
        return false;
    }
    $("#pay_price").val(pay_price);
}

JS;
$this->registerJs($js);
?>
