<?php

use yii\helpers\Html;
use kartik\grid\GridView;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use app\services\PurchaseOrderServices;
use app\services\SupplierServices;
use app\services\BaseServices;
use app\config\Vhelper;
use mdm\admin\components\Helper;
use app\models\PurchaseDemand;
use app\models\PurchaseEstimatedTime;

/* @var $this yii\web\View */
/* @var $searchModel app\models\TodayListSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = '需求跟踪';
$this->params['breadcrumbs'][] = $this->title;

$s =Yii::$app->authManager->getRolesByUser(Yii::$app->user->identity->id);
$manager = array_key_exists('FBA采购经理组',$s);
$purchase = array_key_exists('FBA采购组',$s);
$admin = array_key_exists('超级管理员组',$s);
if ($manager || $purchase || $admin) {
    $bool = true;
} else {
    $bool = false;
}
?>



<div class="purchase-order-index">

    <?= $this->render('_summary-search', ['model' => $searchModel]); ?>

    <p class="clearfix"></p>
    <?php
    if(\mdm\admin\components\Helper::checkRoute('summary-export')) {
        echo Html::a(Yii::t('app', '导出'),['summary-export'], ["class" => "btn btn-info button-a"]);
    }
    ?>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        //'filterModel' => $searchModel,
        'options'=>[
            'id'=>'grid_purchase_order',
        ],
        'filterSelector' => "select[name='".$dataProvider->getPagination()->pageSizeParam."'],input[name='".$dataProvider->getPagination()->pageParam."']",
        'pager' => [
            'class' => \liyunfang\pager\LinkPager::className(),
            'options'=>['class' => 'pagination','style'=> "display:block;"],
            'template' => '{pageButtons} {customPage} {pageSize}', //分页栏布局
            'pageSizeList' => [50,100,200,300,500,1000], //页大小下拉框值
            'customPageWidth' => 50,            //自定义跳转文本框宽度
            'customPageBefore' => ' 跳转到第 ',
            'customPageAfter' => ' 页 ',
        ],
        'columns' => [
            [
                'label'=>'sku',
                'format'=>'raw',
                'value' => function ($model) {
                    $html =  Html::a($model->sku, Yii::$app->params['SKU_ERP_Product_Detail'].$model->sku,['target'=>'blank']);
                    $html .='<br>'.Html::a('<span class="glyphicon glyphicon-stats" style="font-size:10px;color:cornflowerblue;" title="销量库存"></span>', ['product/get-stock-sales','sku'=>$model->sku],
                            [
                                'class' => 'btn btn-xs stock-sales-purchase',
                                'data-toggle' => 'modal',
                                'data-target' => '#create-modal',
                            ]);
                    $html .=Html::a('<span class="glyphicon glyphicon-eye-open" style="font-size:10px;color:cornflowerblue;" title="历史采购记录"></span>', ['purchase-suggest/histor-purchase-info','sku'=>$model->sku,'role'=>'sales'],[
                        'data-toggle' => 'modal',
                        'data-target' => '#create-modal',
                        'class'=>'btn btn-xs stock-sales-purchase',
                    ]);
                    return $html;

                }
            ],
            [
                'label'=>'图片',
                "format" => "raw",
                'value'=> function($model){
                    //return Html::img(Vhelper::downloadImg($model->sku,$model->uploadimgs,2),['width'=>'60px']);
                    //return Vhelper::toSkuImg($model->sku,$model->uploadimgs,'60px');
                    return \toriphes\lazyload\LazyLoad::widget(['src'=>Vhelper::getSkuImage($model->sku),'width'=>'60px']);
                }
            ],
            [
                'label' => '产品名称',
                "format" => "raw",
                'value'=>
                    function($model){
                        return  !empty($model->desc) ? $model->desc->title : '';
                    },

            ],
            [
                'label' => '供应商名称',
                "format" => "raw",
                'visible'=>$bool,
                'value'=>
                    function($model){
                        return  !empty($model->purOrder->supplier_code) ? SupplierServices::getSupplierName($model->purOrder->supplier_code) : '';
                    },

            ],
            [
                'label'=>'需求单号',
                'format'=>'raw',
                'value' => function($model){
                    return  $model->demand_number;
                }
            ],
            [
                'label'=>'需求状态',
                'format'=>'raw',
                'value'=>function($model){
                    return is_array(\app\services\PlatformSummaryServices::getLevelAuditStatus($model->level_audit_status)) ? '状态异常':\app\services\PlatformSummaryServices::getLevelAuditStatus($model->level_audit_status);
                }
            ],
            [
                'label' => '需求时间',
                "format" => "raw",
                'value'=>
                    function($model){
                        return  date('Y-m-d',strtotime($model->create_time));
                    },

            ],
            [
                'label' => '销售组别',
                "format" => "raw",
                'value'=>
                    function($model){
                        return  BaseServices::getAmazonGroupName($model->group_id);
                    },

            ],
            [
                'label'=>'销售',
                'format'=>'raw',
                'value' =>function($model){
                    return $model->sales;
                }
            ],
            [
                'label' => '需求数量',
                "format" => "raw",
                'value'=>
                    function($model){
                        return $model->purchase_quantity;
                    },

            ],
            [
                'label'=>'实际采购数量',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purOrderItem) ? !empty($model->purOrderItem->ctq) ?  $model->purOrderItem->ctq : '' : '';
                    },
                    /*function($model){
                        $ctq = !empty($model->purOrderItem) ? (!empty($model->purOrderItem->ctq) ?  $model->purOrderItem->ctq : '') : '';
                        return PurchaseDemand::getConfirmNumber($model->demand_number,$ctq);
//                        return !empty($model->purOrderItem) ? !empty($model->purOrderItem->ctq) ?  $model->purOrderItem->ctq : '' : '';
                    },*/

            ],
            [
                'label' => '采购仓',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purchase_warehouse) ? BaseServices::getWarehouseCode($model->purchase_warehouse) : '';
                    },

            ],
            [
                'label' => '采购员',
                "format" => "raw",
                'value'=>
                    function($model){
                        //$firstLine = $model->product&&!empty($model->product->product_linelist_id) ? BaseServices::getProductLineFirst($model->product->product_linelist_id) : '';
                        //$data = $model->product_category? \app\models\PurchaseCategoryBind::getBuyer($firstLine).'<br/>':'';
                        //$data= !empty($model->purOrder) ? $model->purOrder->buyer : '';
                        $data= \app\models\PurchaseCategoryBind::getBuyerBySku($model->sku);
                        return $data;
                    },

            ],
            [
                'label' => '采购单号',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purOrder) ? $model->purOrder->pur_number : '';
                    },

            ],
            [
                'label' => '采购单价',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purOrderItem) ? !empty($model->purOrderItem->price) ?  $model->purOrderItem->price : '' : '';
                    },

            ],
            /*[
                'label' => '供应商',
                "format" => "raw",
                'value'=>
                    function($model){
                        $supplierName = !empty($model->purOrder) ? $model->purOrder->supplier_name : '';
                       //$supplierCode = !empty($model->purOrder) ? $model->purOrder->supplier_code : '';
                        return  !empty($supplierName) || !empty($supplierCode) ? $supplierName: '';
                    },

            ],*/
            [
                'label' => '是否含税',
                "format" => "raw",
                'value'=>
                    function($model){
                        $drawArray = ['1'=>'不含税','2'=>'含税'];
                        return !empty($model->purOrder) ? isset($drawArray[$model->purOrder->is_drawback]) ? $drawArray[$model->purOrder->is_drawback]  : '' : '';
                    },
            ],
            [
                'label' => '可做退税',
                "format" => "raw",
                'value'=>
                    function($model){
                        return $model->is_back_tax == 1 ? '可退税' : '';
                    },
            ],
            [
                'label' => '运费',
                "format" => "raw",
                'value'=>
                    function($model){
                        //var_dump($model->ship);

                        return !empty($model->ship) ? !empty($model->ship->freight) ? $model->ship->freight : ''  : '';
                    },

            ],
            [
                'label'=>'物流信息',
                'format'=>'raw',
                'value'=>function($model){
                    if(!empty($model->purOrder)){
                        $data = PurchaseOrderServices::getShippingMethod($model->purOrder->shipping_method) . '<br/>';   //主要通过此种方式实现
                        foreach($model->purOrder->fbaOrderShip as $value) {
                            $s = !empty($value['cargo_company_id']) ? $value['cargo_company_id'] : '';
                            $url = 'https://www.kuaidi100.com/chaxun?com=' . $s . '&nu=' . $value['express_no'];

                            $data .= !preg_match("/^[a-z]/i", $value['cargo_company_id']) ? "<a target='_blank' href='$url'><span class='fa fa-fw fa-truck'  title='快递单号'></span></a>" : "<a target='_blank' href='$url'><span class='fa fa-fw fa-truck'  title='快递单号'></span></a>";   //主要通过此种方式实现

                            $data .= preg_match("/^[a-z]/i", $value['cargo_company_id']) ? $value['cargo_company_id'] . '<br/>' : $value['cargo_company_id'] . '<br/>';   //主要通过此种方式实现

                        }
                        return $data;
                    }
                    return '';
                }
            ],
            [
                'label' => '订单状态',
                "format" => "raw",
                'value'=>
                    function($model){

                        return !empty($model->purOrder) ? PurchaseOrderServices::getPurchaseStatus($model->purOrder->purchas_status) : '';
                    },

            ],
            [
                'label' => '订单审核通过时间',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purOrder) ? !empty($model->purOrder->audit_time) ?  date('Y-m-d',strtotime($model->purOrder->audit_time)) : '' : '';
                    },

            ],
            [
                'label' => '请款时间',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->pay) ? date('Y-m-d',strtotime($model->pay->application_time)) : '';
                    },

            ],
            [
                'label' => '付款状态',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purOrder)&&!empty($model->purOrder->pay_status) ? PurchaseOrderServices::getPayStatus($model->purOrder->pay_status) : '';
                    },

            ],
            [
                'label' => '实际付款时间',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->pay) ? $model->pay->payer_time : '';
                    },

            ],
            [
                'label' => '预计到货时间',
                "format" => "raw",
                'value'=>
                    function($model){
                        $pur_number = !empty($model->purOrder) ? $model->purOrder->pur_number : '';
                        $sku_time = PurchaseEstimatedTime::getEstimatedTime($model->sku,$pur_number);
                        //如果有标记到货时间就取标记到货时间，否则取预计到货时间
                        // if (!empty($sku_time) && strtotime($sku_time) > strtotime('2018-03-01 23:59:59')) {
                        if ( !empty($model->purOrder)&&!empty($model->purOrder->date_eta) ) {
                            $time = !empty($model->purOrder)&&!empty($model->purOrder->date_eta) ? $model->purOrder->date_eta :'';
                        } else {
                            $time = empty($sku_time) ? !empty($model->purOrder)&&!empty($model->purOrder->date_eta) ? $model->purOrder->date_eta :'':$sku_time;
                        }
                        return $time;
                    },

            ],
            [
                'label'=>'权均交期',
                'format'=>'raw',
                'value'=>function($model){
                    return empty($model->fbaAvgArrival) ? 0 : sprintf('%.2f',($model->fbaAvgArrival->avg_delivery_time)/(24*60*60));
                }
            ],
            [
                'label'=>'权均交期时间',
                'format'=>'raw',
                'value'=>function($model){
                    $avg = !empty($model->fbaAvgArrival) ? $model->fbaAvgArrival->avg_delivery_time :0;
                    $audit_time = !empty($model->purOrder) ? $model->purOrder->audit_time : '';
                    return empty($audit_time) ? '' : date('Y-m-d H:i:s',strtotime($audit_time)+round($avg,0));
                }
            ],
            [
                'label'=>'采购到货是否超时',
                'format'=>'raw',
                'value'=>function($model){
                    $data = !empty($model->purOrder) ? \app\models\WarehouseResults::find()->select('instock_date')->where(['pur_number'=>$model->purOrder->pur_number,'sku'=>$model->sku])->scalar() : '';
                    $date = !empty($model->purOrder->date_eta) ? $model->purOrder->date_eta :'';
                    return empty($date)||empty($data) ? '<span style="color: green">否</span>' : ((strtotime($data)-strtotime($date))>3*24*60*60 ? '<span style="color: red">是</span>':'<span style="color: green">否</span>');
                }
            ],
            [
                 'label'=>'权均交期是否超时',
                 'format'=>'raw',
                 'value'=>function($model){
                     $data = !empty($model->purOrder) ? \app\models\WarehouseResults::find()->select('instock_date')->where(['pur_number'=>$model->purOrder->pur_number,'sku'=>$model->sku])->scalar() : '';
                     $avg = !empty($model->fbaAvgArrival) ? $model->fbaAvgArrival->avg_delivery_time :0;
                     $audit_time = !empty($model->purOrder) ? !empty($model->purOrder->audit_time)? $model->purOrder->audit_time :'': '';
                     $fou = '<span style="color: green">否</span>';
                     $shi = '<span style="color: red">是</span>';
                     $instock = $data ? strtotime($data):time();
                     return empty($audit_time) ? $fou: (((strtotime($audit_time)+$avg) <= $instock)? $shi:$fou );
                 }
            ],
            [
                'label' => '备注',
                "format" => "raw",
                'value'=>
                    function($model){
                        return !empty($model->purchase_note) ? $model->purchase_note: '';
                    },
            ],
            [
                'label' => '仓库信息',
                "format" => "raw",
                'value'=>
                    function($model){
                        $data =Html::a('<span class="glyphicon glyphicon-scale" style="font-size:20px;color:#f2adb1;margin-right:10px;" title="单击，查看到货信息"></span>',
                            ['get-platform-detail'],[
                            'class' => 'detail',
                            'data-toggle' => 'modal',
                            'data-target' => '#create-modal','value' =>$model->id,
                        ]);
                        return $data;
                    },

            ],

        ],
        'containerOptions' => ["style"=>"overflow:auto"], // only set when $responsive = false
        'toolbar' =>  [],


        'pjax' => true,
        'bordered' => true,
        'striped' => false,
        'condensed' => true,
        'responsive' => true,
        'hover' => true,
        'floatHeader' => false,
        'showPageSummary' => false,

        'exportConfig' => [
            GridView::EXCEL => [],
        ],
        'panel' => [
            //'heading'=>'<h3 class="panel-title"><i class="glyphicon glyphicon-globe"></i> Countries</h3>',
            'type'=>'success',
            //'after'=>Html::a('<i class="glyphicon glyphicon-repeat"></i> 刷新', ['index'], ['class' => 'btn btn-info']),
        ],
    ]); ?>
</div>
<?php
Modal::begin([
    'id' => 'create-modal',
    'header' => '<h4 class="modal-title">系统信息</h4>',
    'footer' => '<a href="#" class="btn btn-primary closes" data-dismiss="modal">关闭</a>',
    'size'=>'modal-lg',
    'options'=>[
        'data-backdrop'=>'static',//点击空白处不关闭弹窗

    ],
]);
Modal::end();

$js = <<<JS

$(function(){
    $(document).on('click', '.detail', function () {
        var id   = $(this).attr('value');
        $.get($(this).attr('href'), {id:id},
            function (data) {
                $('.modal-body').html(data);
            }
        );
    });
    $(document).on('click', '.stock-sales-purchase', function () {
        $('.modal-body').html('正在请求数据....');
        $.get($(this).attr('href'), {},
            function (data) {
                $('.modal-body').html(data);
            }
        );
    });
	
});
JS;
$this->registerJs($js);
?>
